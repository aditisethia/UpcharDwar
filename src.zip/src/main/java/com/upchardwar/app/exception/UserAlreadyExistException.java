package com.upchardwar.app.exception;

public class UserAlreadyExistException extends RuntimeException{

	public UserAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
