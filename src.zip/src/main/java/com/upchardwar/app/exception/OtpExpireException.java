package com.upchardwar.app.exception;

public class OtpExpireException extends RuntimeException{

	public OtpExpireException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OtpExpireException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
