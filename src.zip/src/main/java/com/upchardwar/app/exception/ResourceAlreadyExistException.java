package com.upchardwar.app.exception;

public class ResourceAlreadyExistException extends RuntimeException {

	public ResourceAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResourceAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
