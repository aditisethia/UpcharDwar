package com.upchardwar.app.exception;

public class ResourceNotApprovedException extends RuntimeException{

	public ResourceNotApprovedException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResourceNotApprovedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
