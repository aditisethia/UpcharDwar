package com.upchardwar.app.services;

public interface ILocationService {

}
