package com.upchardwar.app.security;

import lombok.Data;

@Data
public class UserRequestS {

	private String email;
	private String password;
}
