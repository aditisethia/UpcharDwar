package com.upchardwar.app.entity.status;

public enum InvoiceStatus {

    AWAITING_PAYMENT,
    PAID,
    REFUNDED,
    OTHER
}
