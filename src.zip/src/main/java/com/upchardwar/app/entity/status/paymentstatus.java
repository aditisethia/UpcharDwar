package com.upchardwar.app.entity.status;

public enum paymentstatus {

	ERROR, PENDING, COMPLETED,
}
