package com.upchardwar.app.entity.status;

public enum DiagnosticResult {
 AWATING_RESULT,
 RESULT_RECEIVED;
}
