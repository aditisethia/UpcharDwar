package com.upchardwar.app.entity.status;

public enum PharmaStatus {
	                       
    NEW,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    RETURNED;
}