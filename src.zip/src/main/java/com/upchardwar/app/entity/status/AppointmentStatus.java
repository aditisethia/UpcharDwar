package com.upchardwar.app.entity.status;

public enum AppointmentStatus {

	SCHEDULED, CANCELLED, COMPLETED,
}
