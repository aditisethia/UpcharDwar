package com.upchardwar.app.entity.status;

public enum LabStatus {

    PENDING,
    COMPLETED,
    CANCELLED,
    IN_PROGRESS,
    DELIVERED,

}
