package com.upchardwar.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpchardwarBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
